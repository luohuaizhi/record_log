from .mrlog import record_log

name = "mrlog"

__all__ = ["record_log"]
