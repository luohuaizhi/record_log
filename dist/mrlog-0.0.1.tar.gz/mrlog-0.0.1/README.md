# record_log
record log to db(mongodb)
